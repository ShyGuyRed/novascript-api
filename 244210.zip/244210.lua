-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 244210
-- Name: Assetto Corsa
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Assetto Corsa
-- App ID: 244210

addappid(244210)  -- Assetto Corsa
addappid(228983)  -- App 228983
addappid(228984)  -- App 228984
addappid(228985)  -- App 228985
addappid(229006)  -- App 229006
addappid(244210)  -- Assetto Corsa

addappid(244211, 1, "7cbd509f5c33d07d80375e94bb55d9951e1bea4861f99c10421e1e37d9c6e6a7")  -- Depot 244211
setManifestid(244211, "4950336537810395690")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

addappid(347990)  -- Assetto Corsa - Dream Pack 1 (DLC)
addappid(347990, 1, "789cc0104f4b59d55b96c7a310101e6c4766036645244af72bbda39ae7ad03aa")  -- Depot 347990
setManifestid(347990, "6791848099595238056")

addappid(404430)  -- Assetto Corsa - Dream Pack 2 (DLC)
addappid(404430, 1, "23de34042efaf92152ae28c16315c8ca57ec21f59069a50ed08ee7c161a07ccb")  -- Depot 404430
setManifestid(404430, "3305068408340865881")

addappid(423630)  -- Assetto Corsa - Dream Pack 3 (DLC)
addappid(423630, 1, "e103fe276e451f80152f996b0609a23fa4b816cfba6ce09afd352ba595d58a87")  -- Depot 423630
setManifestid(423630, "143182663462094843")

addappid(467980)  -- Assetto corsa - Japanese Pack (DLC)
addappid(467980, 1, "8e4d401e0d78fceea18c3a6e3da94f91cfc1ea9620b93bfe1e7cd93fa83bcae7")  -- Depot 467980
setManifestid(467980, "1919441460742340991")

addappid(493190)  -- Assetto Corsa - Red Pack (DLC)
addappid(493190, 1, "7fce09bb241009bdbfd30240ca2d73d3f8d50c85236266e8a64dac9b187a981c")  -- Depot 493190
setManifestid(493190, "6702276192559020176")

addappid(509350)  -- Assetto Corsa -Tripl3 Pack (DLC)
addappid(509350, 1, "304503a53fcb2b4a404d501ab0f4b44e83590876df21979e5308c07935da2761")  -- Depot 509350
setManifestid(509350, "5232019972713022175")

addappid(526060)  -- Assetto Corsa - Porsche Pack I (DLC)
addappid(526060, 1, "5cdea49412168d3835761d2454bf97a87d7261c6f6058e0095edab66d9a41461")  -- Depot 526060
setManifestid(526060, "1609580688491246185")

addappid(540710)  -- Assetto Corsa - Porsche Pack II (DLC)
addappid(540710, 1, "9c7da758ba906a41a39245cd6dcc6f69547231a9d6fb1973b39313afe5354fd4")  -- Depot 540710
setManifestid(540710, "7212972613834439529")

addappid(540711)  -- Assetto Corsa - Porsche Pack III (DLC)
addappid(540711, 1, "6f2fac093cc2cf5e1d1ab99c1c1a766422f97502d689a93cf51076c8aa8d0cf2")  -- Depot 540711
setManifestid(540711, "5205419179365407728")

addappid(619680)  -- Assetto Corsa - Ready To Race Pack (DLC)
addappid(619680, 1, "78bda0cdc6e6a57c2a9e2b081db27d0ce9f34bd02196d2b996d17593f77bd124")  -- Depot 619680
setManifestid(619680, "5396831645102266732")

addappid(675590)  -- Assetto Corsa - Ferrari 70th Anniversary Pack (DLC)
addappid(675590, 1, "962fcf3fd904ee05f71944f3b51692c67799b42d94a81ea6cfc368ea60889f12")  -- Depot 675590
setManifestid(675590, "4281175229020665840")

addappid(1387540)  -- App 1387540
addappid(1387540, 1, "e9c1b30b9c55940e7a331ec99a84c63c1594420060295bdee11f86c5bd15eb85")  -- Depot 1387540
setManifestid(1387540, "9131952850290736705")

setManifestid(1552200, "8950059475089434747")

addappid(244210, 1, "f23245bf2e189422f4977c167c5b7f0d5ecccbc7a595e398f8936329d080ff12")  -- Depot 244210 (Shared)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b")  -- Depot 228983
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")  -- Depot 228984
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c")  -- Depot 228985
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416")  -- Depot 229006

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:24:52 GMT
-- Depots: 19 | Manifests: 15 | Missing: 5
-- DLCs: 16
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


