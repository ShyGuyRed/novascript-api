-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 230290
-- Name: Universe Sandbox
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Universe Sandbox
-- App ID: 230290

addappid(230290)  -- Universe Sandbox

addappid(230291, 1, "d4032e706d2ed817e94dbf0ee8e96854deacf119261215d15a4f11b481673e64")  -- Depot 230291
setManifestid(230291, "6560556950488346787")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

addappid(230292, 1, "7a549608cadcf13742cccc734cbca6b6080db136ac34e96993fbf0cc8da7db8c")  -- Depot 230292
setManifestid(230292, "4013160134694945001")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:27:49 GMT
-- Depots: 3 | Manifests: 3 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


