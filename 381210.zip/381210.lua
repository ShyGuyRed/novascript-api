-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 381210
-- Name: Dead by Daylight
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Dead by Daylight
-- App ID: 381210

addappid(4019590)  -- Dead by Daylight - Sinister Grace (DLC)
addappid(228989)  -- App 228989
addappid(228990)  -- App 228990
addappid(381210)  -- Dead by Daylight
addappid(381213)  -- App 381213
addappid(3884020)  -- Dead by Daylight: The Walking Dead (DLC)
addappid(3796620)  -- Dead by Daylight: Five Nights at Freddy’s (DLC)
addappid(3698790)  -- Dead by Daylight - Steady Pulse (DLC)
addappid(3448670)  -- Dead by Daylight - Tokyo Ghoul (DLC)
addappid(3261720)  -- Dead by Daylight - Doomed Course (DLC)
addappid(3103150)  -- Dead by Daylight - Castlevania Chapter (DLC)
addappid(3024580)  -- Dead by Daylight - Tomb Raider Chapter (DLC)
addappid(2958440)  -- Dead by Daylight - Dungeons & Dragons (DLC)
addappid(2661270)  -- Dead by Daylight - All Things Wicked Chapter (DLC)
addappid(2661250)  -- Dead by Daylight - Alan Wake Chapter (DLC)
addappid(2922730)  -- Dead by Daylight - Endless Hunt Pack (DLC)
addappid(2526530)  -- Dead by Daylight - Maddening Darkness Pack (DLC)
addappid(2526540)  -- Dead by Daylight - Old Wounds Pack (DLC)
addappid(2526550)  -- Dead by Daylight - Macabre Tales Pack (DLC)
addappid(2656010)  -- Dead by Daylight - Chucky Chapter (DLC)
addappid(2515990)  -- Dead by Daylight - Alien Chapter Pack (DLC)

addappid(381210)  -- Dead by Daylight
addappid(1009820)  -- Dead by Daylight - Demise of the Faithful Chapter (DLC)
addappid(1009821)  -- Dead by Daylight - Ash vs Evil Dead (DLC)
addappid(1089270)  -- Dead by Daylight - Ghost Face® (DLC)
addappid(1135280)  -- Dead by Daylight - Stranger Things Chapter (DLC)
addappid(1199880)  -- Dead by Daylight - Cursed Legacy Chapter (DLC)
addappid(1251000)  -- Dead by Daylight - Chains of Hate Chapter (DLC)
addappid(1324970)  -- Dead By Daylight - Silent Hill Chapter (DLC)
addappid(1324971)  -- Dead by Daylight - Silent Hill Cosmetic Pack (DLC)
addappid(1408020)  -- Dead by Daylight - Descend Beyond Chapter (DLC)
addappid(1474030)  -- Dead by Daylight - A Binding of Kin Chapter (DLC)
addappid(1557310)  -- Dead by Daylight - All-Kill Chapter (DLC)
addappid(1622940)  -- Dead by Daylight - Terror Expansion Pack (DLC)
addappid(1622941)  -- Dead by Daylight - Escape Expansion Pack (DLC)
addappid(1634040)  -- Dead by Daylight - Resident Evil Chapter (DLC)
addappid(1734080)  -- Dead by Daylight - Hellraiser Chapter (DLC)
addappid(1763310)  -- Dead by Daylight - Hour of the Witch Chapter (DLC)
addappid(1804690)  -- Dead by Daylight - Portrait of a Murder Chapter (DLC)
addappid(1899750)  -- Dead by Daylight - Sadako Rising Chapter (DLC)
addappid(1985790)  -- Dead by Daylight - Roots of Dread Chapter (DLC)
addappid(2102730)  -- Dead by Daylight - Resident Evil: PROJECT W Chapter (DLC)
addappid(2198470)  -- Dead by Daylight - Forged in Fog Chapter (DLC)
addappid(2294610)  -- Dead by Daylight - Tools of Torment Chapter (DLC)
addappid(2399750)  -- Dead by Daylight - End Transmission Chapter (DLC)
addappid(2405130)  -- Dead by Daylight x Attack on Titan: Armored Pack (DLC)
addappid(2405140)  -- Dead by Daylight x Attack on Titan: War Hammer Pack (DLC)
addappid(2469400)  -- Dead by Daylight - Nicolas Cage Chapter Pack (DLC)
addappid(4318580)  -- Dead by Daylight: Stranger Things Chapter 2 (DLC)
addappid(489980)  -- App 489980
addappid(492360)  -- App 492360
addappid(509060)  -- Dead by Daylight - The Last Breath Chapter (DLC)
addappid(509061)  -- App 509061
addappid(516780)  -- App 516780
addappid(528320)  -- App 528320
addappid(528321)  -- App 528321
addappid(528322)  -- App 528322
addappid(528323)  -- App 528323
addappid(528324)  -- App 528324
addappid(530710)  -- Dead by Daylight - The 80's Suitcase (DLC)
addappid(530711)  -- Dead by Daylight - The Halloween® Chapter (DLC)
addappid(534130)  -- App 534130
addappid(534131)  -- App 534131
addappid(554380)  -- Dead by Daylight - The Bloodstained Sack (DLC)
addappid(554381)  -- Dead by Daylight - Of Flesh and Mud Chapter (DLC)
addappid(556360)  -- App 556360
addappid(556370)  -- App 556370
addappid(556371)  -- App 556371
addappid(562130)  -- App 562130
addappid(566500)  -- App 566500
addappid(573240)  -- App 573240
addappid(573940)  -- Dead by Daylight - Left Behind (DLC)
addappid(577900)  -- App 577900
addappid(577901)  -- Dead by Daylight - Headcase (DLC)
addappid(582600)  -- Dead by Daylight - Spark of Madness Chapter (DLC)
addappid(620230)  -- App 620230
addappid(627510)  -- Dead by Daylight - Charity Case (DLC)
addappid(639710)  -- App 639710
addappid(661770)  -- Dead by Daylight - A Lullaby for the Dark Chapter (DLC)
addappid(700280)  -- Dead by Daylight - Leatherface™ (DLC)
addappid(700282)  -- Dead by Daylight - A Nightmare on Elm Street™ (DLC)
addappid(724650)  -- App 724650
addappid(750380)  -- App 750380
addappid(750381)  -- Dead by Daylight - The Saw® Chapter (DLC)
addappid(799200)  -- Dead by Daylight - Curtain Call Chapter (DLC)
addappid(925750)  -- Dead by Daylight - Shattered Bloodline Chapter (DLC)
addappid(971790)  -- Dead by Daylight - Darkness Among Us Chapter (DLC)
addappid(381212,0,"d514d170477029b1fc73e157f9550e3591facfc4508a7568deaf4599fc3a54b4")  -- Depot 381212
setManifestid(381212,"5921550076694751899")
addappid(381211,0,"66477a849ed619510d127ff3f05d4d37b38a04fd7074654337053dfe817798ca")  -- Depot 381211
setManifestid(381211, "5071786799861372686")

addappid(381210, 1, "f17be424bd1dc965706d5527f803a0c4ae2c7aae87449be6f5bab17b7ac3a20c")  -- Depot 381210 (Shared)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")  -- Depot 228989
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
addappid(381213, 1, "525dbbc5d40bca2cd810f8cb48945f893aa16ca7c1ea90895e0d0c498f183ff5")  -- Depot 381213 (Shared)

-- ═══════════════════════════════════════════════════════
-- Generated: Sat, 11 Apr 2026 08:40:28 GMT
-- Depots: 6 | Manifests: 2 | Missing: 4
-- DLCs: 85
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


