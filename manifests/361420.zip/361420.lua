-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 361420
-- Name: ASTRONEER
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: ASTRONEER
-- App ID: 361420

addappid(3884830)  -- Astroneer: Megatech (DLC)
addappid(3042220)  -- ASTRONEER: Glitchwalkers (DLC)
addappid(3315070)  -- ASTRONEER: Glitchwalkers - Deluxe Cosmetic Pack (DLC)
addappid(2876620)  -- ASTRONEER: Evolution Bundle (DLC)
addappid(2567000)  -- ASTRONEER Suit Bundle (DLC)
addappid(2567010)  -- ASTRONEER Athleisure Bundle (DLC)
addappid(2566990)  -- ASTRONEER Essential Bundle (DLC)
addappid(4144820)  -- Astroneer: Megatech - Deluxe Cosmetic Pack (DLC)

addappid(361420)  -- ASTRONEER
addappid(228986,0,"51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")  -- Depot 228986
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
addappid(361422,0,"471756d013ea0594ce2fe60fa33915663d90cf64b086b5b992b85f5fc73d5283")  -- Depot 361422
setManifestid(228986,"8782296191957114623")
setManifestid(228990,"1829726630299308803")
setManifestid(361422, "2114990677475212820")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 15:16:44 GMT
-- Depots: 3 | Manifests: 3 | All included ✓
-- DLCs: 8
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


