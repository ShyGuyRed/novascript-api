-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 739630
-- Name: Phasmophobia
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Phasmophobia
-- App ID: 739630

addappid(739630)  -- Phasmophobia

addappid(739631, 1, "a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c")  -- Depot 739631
setManifestid(739631, "4519709448788802870")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:23:08 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


