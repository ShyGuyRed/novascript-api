-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 3684710
-- Name: My sexy Neighbour 2
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: My sexy Neighbour 2
-- App ID: 3684710

addappid(3684710)  -- My sexy Neighbour 2
addappid(3684711,0,"0b2ea915b88b5207d9cc94d94f2d85c33277b09ff15781326a589bd4f8ef4158")  -- Depot 3684711
-- ═══════════════════════════════════════════════════════
-- Generated: Mon, 13 Apr 2026 08:45:03 GMT
-- Depots: 1 | Manifests: 0 | Missing: 1
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


