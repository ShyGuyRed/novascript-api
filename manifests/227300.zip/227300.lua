-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 227300
-- Name: Euro Truck Simulator 2
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Euro Truck Simulator 2
-- App ID: 227300

addappid(227300)  -- Euro Truck Simulator 2
addappid(4348650)  -- Euro Truck Simulator 2 - Bobcat Cargo Pack (DLC)
addappid(2780810)  -- Euro Truck Simulator 2 - Nordic Horizons (DLC)
addappid(1456860)  -- Euro Truck Simulator 2 - Farm Machinery (DLC)
addappid(4159240)  -- Euro Truck Simulator 2 - Forest Machinery (DLC)
addappid(2604420)  -- Euro Truck Simulator 2 - Greece (DLC)
addappid(3977520)  -- Euro Truck Simulator 2 - DAF XF Electric (DLC)
addappid(3335300)  -- Euro Truck Simulator 2 - Greek Mythology Pack (DLC)
addappid(3323360)  -- Euro Truck Simulator 2 - Volvo FH Series 6 (DLC)
addappid(3354860)  -- Euro Truck Simulator 2 - Iveco S-Way (DLC)
addappid(3323350)  -- Euro Truck Simulator 2 - Volvo FH Series 5 (DLC)
addappid(3034950)  -- Euro Truck Simulator 2 - Kässbohrer Trailer Pack (DLC)
addappid(933610)  -- Euro Truck Simulator 2 - Krone Trailer Pack (DLC)
addappid(3034940)  -- Euro Truck Simulator 2 - Kögel Trailer Pack (DLC)
addappid(2780800)  -- Euro Truck Simulator 2 - JCB Equipment Pack (DLC)
addappid(3035040)  -- Euro Truck Simulator 2 - Scania S BEV (DLC)
addappid(2932420)  -- Euro Truck Simulator 2 - Renault Trucks E-Tech T (DLC)
addappid(2579670)  -- Euro Truck Simulator 2 - Modern Lines Paint Jobs Pack (DLC)
addappid(1967650)  -- Euro Truck Simulator 2 - Street Art Paint Jobs Pack (DLC)
addappid(1918370)  -- Euro Truck Simulator 2 - Ukrainian Paint Jobs Pack (DLC)
addappid(1967640)  -- Euro Truck Simulator 2 - Renault Trucks T Tuning Pack (DLC)
addappid(1209460)  -- Euro Truck Simulator 2 - Iberia (DLC)
addappid(1056760)  -- Euro Truck Simulator 2 - Road to the Black Sea (DLC)
addappid(925580)  -- Euro Truck Simulator 2 - Beyond the Baltic Sea (DLC)
addappid(558244)  -- Euro Truck Simulator 2 - Italia (DLC)
addappid(531130)  -- Euro Truck Simulator 2 - Vive la France ! (DLC)
addappid(304212)  -- Euro Truck Simulator 2 - Scandinavia (DLC)
addappid(227310)  -- Euro Truck Simulator 2 - Going East! (DLC)
addappid(558245)  -- Euro Truck Simulator 2 - Special Transport (DLC)
addappid(1704460)  -- Euro Truck Simulator 2 - Volvo Construction Equipment (DLC)
addappid(531131)  -- Euro Truck Simulator 2 - Heavy Cargo Pack (DLC)
addappid(304214)  -- Euro Truck Simulator 2 - High Power Cargo Pack (DLC)
addappid(1056761)  -- Euro Truck Simulator 2 - Actros Tuning Pack (DLC)
addappid(461244)  -- Euro Truck Simulator 2 - Mighty Griffin Tuning Pack (DLC)
addappid(1299530)  -- Euro Truck Simulator 2 - FH Tuning Pack (DLC)
addappid(461249)  -- Euro Truck Simulator 2 - XF Tuning Pack (DLC)
addappid(388477)  -- Euro Truck Simulator 2 - Schwarzmüller Trailer Pack (DLC)
addappid(1117140)  -- Euro Truck Simulator 2 - Goodyear Tyres Pack (DLC)
addappid(2833100)  -- Euro Truck Simulator 2 - Schmitz Cargobull Trailer Pack (DLC)
addappid(1209461)  -- Euro Truck Simulator 2 - HS-Schoch Tuning Pack (DLC)
addappid(388475)  -- Euro Truck Simulator 2 - Wheel Tuning Pack (DLC)
addappid(388470)  -- Euro Truck Simulator 2 - Cabin Accessories (DLC)
addappid(1415700)  -- Euro Truck Simulator 2 - Super Stripes Paint Jobs Pack (DLC)
addappid(318521)  -- Euro Truck Simulator 2 - Raven Truck Design Pack (DLC)
addappid(461242)  -- Euro Truck Simulator 2 - Window Flags (DLC)
addappid(526950)  -- Euro Truck Simulator 2 - Lunar New Year Pack (DLC)
addappid(558243)  -- Euro Truck Simulator 2 - Valentine's Paint Jobs Pack (DLC)
addappid(292320)  -- Euro Truck Simulator 2 - Force of Nature Paint Jobs Pack (DLC)
addappid(258460)  -- Euro Truck Simulator 2 - Halloween Paint Jobs Pack (DLC)
addappid(266930)  -- Euro Truck Simulator 2 - Ice Cold Paint Jobs Pack (DLC)
addappid(318520)  -- Euro Truck Simulator 2 - Christmas Paint Jobs Pack (DLC)
addappid(925650)  -- Euro Truck Simulator 2 - Space Paint Jobs Pack (DLC)
addappid(461248)  -- Euro Truck Simulator 2 - Pirate Paint Jobs Pack (DLC)
addappid(266931)  -- Euro Truck Simulator 2 - Prehistoric Paint Jobs Pack (DLC)
addappid(347212)  -- Euro Truck Simulator 2 - Viking Legends (DLC)
addappid(558240)  -- Euro Truck Simulator 2 - Dragon Truck Design Pack (DLC)
addappid(304210)  -- Euro Truck Simulator 2 - Fantasy Paint Jobs Pack (DLC)
addappid(297790)  -- Euro Truck Simulator 2 - Metallic Paint Jobs Pack (DLC)
addappid(301180)  -- Euro Truck Simulator 2 - Flip Paint Designs (DLC)
addappid(318511)  -- Euro Truck Simulator 2 - Czech Paint Jobs Pack (DLC)
addappid(461240)  -- Euro Truck Simulator 2 - Slovak Paint Jobs Pack (DLC)
addappid(304020)  -- Euro Truck Simulator 2 - Polish Paint Jobs Pack (DLC)
addappid(318500)  -- Euro Truck Simulator 2 - German Paint Jobs Pack (DLC)
addappid(461243)  -- Euro Truck Simulator 2 - Austrian Paint Jobs Pack (DLC)
addappid(461246)  -- Euro Truck Simulator 2 - Swiss Paint Jobs Pack (DLC)
addappid(388479)  -- Euro Truck Simulator 2 - Hungarian Paint Jobs Pack (DLC)
addappid(347190)  -- Euro Truck Simulator 2 - Norwegian Paint Jobs Pack (DLC)
addappid(347211)  -- Euro Truck Simulator 2 - Swedish Paint Jobs Pack (DLC)
addappid(540720)  -- Euro Truck Simulator 2 - Finnish Paint Jobs Pack (DLC)
addappid(347210)  -- Euro Truck Simulator 2 - Danish Paint Jobs Pack (DLC)
addappid(980590)  -- Euro Truck Simulator 2 - Estonian Paint Jobs Pack (DLC)
addappid(980591)  -- Euro Truck Simulator 2 - Latvian Paint Jobs Pack (DLC)
addappid(980592)  -- Euro Truck Simulator 2 - Lithuanian Paint Jobs Pack (DLC)
addappid(388471)  -- Euro Truck Simulator 2 - Michelin Fan Pack (DLC)
addappid(909640)  -- Euro Truck Simulator 2 - Dutch Paint Jobs Pack (DLC)
addappid(461241)  -- Euro Truck Simulator 2 - Spanish Paint Jobs Pack (DLC)
addappid(876980)  -- Euro Truck Simulator 2 - Portuguese Paint Jobs Pack (DLC)
addappid(318510)  -- Euro Truck Simulator 2 - French Paint Jobs Pack (DLC)
addappid(388476)  -- Euro Truck Simulator 2 - Italian Paint Jobs Pack (DLC)
addappid(558241)  -- Euro Truck Simulator 2 - Romanian Paint Jobs Pack (DLC)
addappid(1159030)  -- Euro Truck Simulator 2 - Bulgarian Paint Jobs  Pack (DLC)
addappid(297791)  -- Euro Truck Simulator 2 - UK Paint Jobs Pack (DLC)
addappid(297792)  -- Euro Truck Simulator 2 - Irish Paint Jobs Pack (DLC)
addappid(297793)  -- Euro Truck Simulator 2 - Scottish Paint Jobs Pack (DLC)
addappid(540721)  -- Euro Truck Simulator 2 - Belgian Paint Jobs Pack (DLC)
addappid(388474)  -- Euro Truck Simulator 2 - Turkish Paint Jobs Pack (DLC)
addappid(304213)  -- Euro Truck Simulator 2 - Canadian Paint Jobs Pack (DLC)
addappid(304211)  -- Euro Truck Simulator 2 - USA Paint Jobs Pack (DLC)
addappid(304140)  -- Euro Truck Simulator 2 - Brazilian Paint Jobs Pack (DLC)
addappid(388472)  -- Euro Truck Simulator 2 - Japanese Paint Jobs Pack (DLC)
addappid(461245)  -- Euro Truck Simulator 2 - South Korean Paint Jobs Pack (DLC)
addappid(461247)  -- Euro Truck Simulator 2 - Chinese Paint Jobs Pack (DLC)
addappid(558242)  -- Euro Truck Simulator 2 - Australian Paint Jobs Pack (DLC)
addappid(1650650)  -- Euro Truck Simulator 2 - DAF XG/XG+ (DLC)
addappid(1068290)  -- Euro Truck Simulator 2 - Pink Ribbon Charity Pack (DLC)
addappid(2004210)  -- Euro Truck Simulator 2 - West Balkans (DLC)
addappid(2193220)  -- Euro Truck Simulator 2 - Feldbinder Trailer Pack (DLC)
addappid(1536500)  -- Euro Truck Simulator 2 - Heart of Russia (DLC)
addappid(2371170)  -- Euro Truck Simulator 2 - MAN TGX (DLC)
addappid(2455690)  -- Euro Truck Simulator 2 - Wielton Trailer Pack (DLC)
addappid(2569750)  -- Euro Truck Simulator 2 - TIRSAN Trailer Pack (DLC)
addappid(2611740)  -- Euro Truck Simulator 2 - DAF XD (DLC)
addappid(347213)  -- Euro Truck Simulator 2 - Russian Paint Jobs Pack (DLC)
addappid(3872920)  -- Euro Truck Simulator 2 - KRONE Agriculture Equipment (DLC)

addappid(3796990)  -- Euro Truck Simulator 2 - Iceland (DLC)
addappid(3809270)  -- Euro Truck Simulator 2 - Coaches (DLC)
addappid(3851260)  -- Euro Truck Simulator 2 - Isle of Ireland (DLC)
addappid(227300,1,"4efc6eb3aea74680b954e5b88327ec42ef52984cb390f9dc905aab42a4ae6652")  -- Depot 227300 (Shared)
addappid(227301,0,"1baf18f6181ad3f9ce663dab07f93ba0f3f5194c82b64785e4cd9f63f3a56b28")  -- Depot 227301
addappid(227302,0,"edfb6f81d8ec91175145051344fdf788840b2235df88cca912a7602de47f54af")  -- Depot 227302
addappid(227310,0,"b06666dc044784f4331b6572132630cb7b36fd1c83688aa215f808fc8460729d")  -- Depot 227310
addappid(258460,0,"a3f49706464f613855bdb86f4aa8ad16370390f18c059398495dbd76e22bae01")  -- Depot 258460
addappid(266930,0,"f4d470f5465831a9dd38238f63c9cb1dc198f2c71fbfd95ec811c3d536083afb")  -- Depot 266930
addappid(266931,0,"e7e3ea706608c68f2c98adad6195b9e99224b03a061dab06708283110249b71e")  -- Depot 266931
addappid(292320,0,"90f9db92d02b768332a169e698883316b4f8390294a000dbb728bf8db4bb6ea6")  -- Depot 292320
addappid(297790,0,"0233fe7dd02c1e88ba24e3f1d37532b77a850bf9ab456d7ebc6277b8a40360ef")  -- Depot 297790
addappid(297791,0,"59ec65b036441b6041336c12e035f557aa24ec9a76339b833b97eea3bc599f5f")  -- Depot 297791
addappid(297792,0,"bdfd47562c2dbc16d82fd2874062d5ec0719c39f0e4651a024750b36efb56aeb")  -- Depot 297792
addappid(297793,0,"6884199428ed7ac5db8a1c7fce8fff2dfe0b9c64f83bc5e2c5983a055e7b31a3")  -- Depot 297793
addappid(301180,0,"1392869053d38e8512ccf586fafc2dcf914a4a7e5eb73c11b4ce7a5f0dbc19a6")  -- Depot 301180
addappid(304020,0,"da29a5daa49c3470f56dd4cac21ad1ad4e1b4a3fa9c9d0ba84936ec1b14f81ec")  -- Depot 304020
addappid(304140,0,"3eda1b6792cc2682797d1c86e5d38cb50fa601d5f2f62d367ab00b03254e23a9")  -- Depot 304140
addappid(304210,0,"ca10ce279520e0e9a9d898a436497106b4dbb5afd82e990c56309ea5f6ea7f16")  -- Depot 304210
addappid(304211,0,"0aca8cf58b08cbc0381262d0e6ba19d5dccb4aebd904243553cb8fab44358890")  -- Depot 304211
addappid(304212,0,"e4eb05d826bd438b1cf3adbd187291b77b593745a3d9cb20a415c85cfc380bb6")  -- Depot 304212
addappid(304213,0,"faf0dd632893269bcc953ed6acba65f4cc31d09fbf7ba4d52c73e21bf5f5f5d2")  -- Depot 304213
addappid(304214,0,"884afba8823c2c7f29594929bea51b3b4d104c94d1eed509f7cbb74e6879a4b9")  -- Depot 304214
addappid(318500,0,"d4684f2f1f482c5946d5ee03422739c055a78754c205f6817efe66c40a028bd0")  -- Depot 318500
addappid(318510,0,"70f48e349fc6d019a92411b5390a3ca0ea301ced3b96a234ce62b843a9aaf5a2")  -- Depot 318510
addappid(318511,0,"a2af29b1f466408287baa92fe53a054c5edee9ad5bbcbbd31c518a6af9664281")  -- Depot 318511
addappid(318520,0,"2c83753aedd232b4abaadc6192612fb42037a951ffd0c5a7704f6049f90e6fc0")  -- Depot 318520
addappid(318521,0,"e86fdf8ee51e4b5f471c801c2685c034bf527852dd45e2b7875a1148bad09920")  -- Depot 318521
addappid(347190,0,"6e38118275d80be4547dbc47591536f9115b7371c9740190eb84e9b28ea2cf4a")  -- Depot 347190
addappid(347210,0,"c6f97f2a29f4373af3f5f4288de1c7652edaf2ccdc83d19b0908abdb920699c7")  -- Depot 347210
addappid(347211,0,"3e727c3f2459b02345df4ba755343cc85e568f11e00d2921a6ae7a3eaaea80ea")  -- Depot 347211
addappid(347212,0,"d45d628eb639b8998835fd40634312e5b41366ab44f7041d4e712934c6687753")  -- Depot 347212
addappid(347213,0,"891169b29f28bd734fcd67f7711d95cbb9d6f8ebf9a9dfe0bbd257a4b0505ccb")  -- Depot 347213
addappid(388470,0,"a729fbd028cfa164dba072e2c6c9ee3c1766f0c59f99b4a208f3e8e3b87e2702")  -- Depot 388470
addappid(388471,0,"f3a39ad83fc8e32da3e0cb5795388a19c1b9ffa33408f14dbc6a8d00324f5d08")  -- Depot 388471
addappid(388472,0,"aeb199820883929e63403f977bbc64a9074e190bc15e9c63c69c62b207828d8c")  -- Depot 388472
addappid(388474,0,"77991e467d4682641e5ce0cecec31522985864eb6fb73ed256452da4406a536e")  -- Depot 388474
addappid(388475,0,"ab0619b51d856c6c0de489a9bb68bc90dd7719b154438352d22ca0d3cb19bcb1")  -- Depot 388475
addappid(388476,0,"87711c8a894df742f5b3b2bef8de98b514577fd683c89d40d2341bcfef24ddef")  -- Depot 388476
addappid(388477,0,"68c0c97eb4e09492c0a3e486fb76265f9e16869ccbb5dda4bf6d4025d075724c")  -- Depot 388477
addappid(388478,0,"37e441d79e75d5e2fc7af4075ea3afbb4309ce05a27fc63f81419867ee29cc84")  -- Depot 388478
addappid(388479,0,"dbe25d6a318f8f1c1596ed31f20e1b46d80d8a8c6bd6132d1de4aacee59e3c4f")  -- Depot 388479
addappid(461240,0,"fa0637146d19b8b2d950139cf43a17d6e9cb310e1890e6b51bbd8c0dd7a86667")  -- Depot 461240
addappid(461241,0,"7646ba3063910ff501e7eaf351220bbca90e90966948eab097163537b4b4094e")  -- Depot 461241
addappid(461242,0,"55b64424abcb936aa720b487af255b65658fb43250fda2182e3e9a78db56eeae")  -- Depot 461242
addappid(461243,0,"ec1615229bc77d971fe9d99fddb9ea4208b87edad45b7d374724592b13409b73")  -- Depot 461243
addappid(461244,0,"5179b4667e35b10483b6e4d6e920cae7aa1466119c369d60f817daf39a182b6b")  -- Depot 461244
addappid(461245,0,"d8594320bae45917c8c163c392d336c6b2434a7864476f0a362522a401769aeb")  -- Depot 461245
addappid(461246,0,"478e411d19999bd79bb97f6bdfd26bcde124255f77758980b6b1eb5b941ebee3")  -- Depot 461246
addappid(461247,0,"85e8e82506156b32a06db9dcc41e42060f78434b047c7ce8e24b9757efe117fd")  -- Depot 461247
addappid(461248,0,"170a233de5371a3103a336b9e16c8af6af2231301cbe72d3c95defa393526e62")  -- Depot 461248
addappid(461249,0,"1d99a3412d2a4c03edeeeb15e8a0a8058556a2982f93ea3d90ded2a92c289dce")  -- Depot 461249
addappid(526950,0,"cc767e163423b6b03dc66f7c695212b4deb1978c89bb0000a4427db2a39bcf0d")  -- Depot 526950
addappid(531130,0,"2009ea02e74e2e3438c16df3475863ac4fea7a409bef60a339fad9781f1b3185")  -- Depot 531130
addappid(531131,0,"3cac01adc92d11de7a91d5e413a3762670847261f8cf7bb131faec3ba9b99db3")  -- Depot 531131
addappid(540720,0,"b3f6c3fbc60c3b5ebafb8b7d8f80a3b1985e8958f41920fd4f12777d266a90f5")  -- Depot 540720
addappid(540721,0,"273635bd103f2ca132ec8ca31f65b805ee59b498741edeea4a037d62edb1f9e4")  -- Depot 540721
addappid(558240,0,"998330b0c6bf49c43a810186d568047bce0cca54226dec5195eaef5f1e06d997")  -- Depot 558240
addappid(558241,0,"3f1d8d6a37ec6ac17285059ac7ffceaac561e83b78c5e3f8c19159393a0fcb1c")  -- Depot 558241
addappid(558242,0,"7748a8e37c27b371b7692d2ad50f4d210e8c3bb6683047a4b97774c89bfd247c")  -- Depot 558242
addappid(558243,0,"84f20ef511071ab8920d5d2a1396660e156023cfa9dbb74ab956dbc58fbeba8e")  -- Depot 558243
addappid(558244,0,"9719afc41fd0ac583693e96fb57d47629e70b466ed8e1ba653f9e584741551ff")  -- Depot 558244
addappid(558245,0,"78a96462ea125cfa8fcc98f7832146f9e1e8a3205a57b18773cd243b535f47ce")  -- Depot 558245
addappid(876980,0,"cf85cedf09ec405f21338fce1cf9efa360710fd5be02c97420b2534d871680bd")  -- Depot 876980
addappid(909640,0,"93a0622d37996d65d3ebccfe109847c6be9118dcb5f980bb5d317d29c89f4616")  -- Depot 909640
addappid(925580,0,"aec0bb982622c145e437172016f65040db8b8d005d7de9ddff758f292f035ab1")  -- Depot 925580
addappid(925650,0,"754a3ef9021990cf28a11008df0387fb87e9b799e83ad10090edc69bf0bbc276")  -- Depot 925650
addappid(933610,0,"ddec5ac79ef43babb022170583cf8dde89b8806caccfca75ead38d8adf53ee3f")  -- Depot 933610
addappid(980590,0,"e94dd3368f57beea8e661d243f7106b88befdd6e6f448810fa65a00de6a2300f")  -- Depot 980590
addappid(980591,0,"5f01151bee644c449f49705841a63539f3c18cface0c0475f004a8d766595ebf")  -- Depot 980591
addappid(980592,0,"6938e01c6c62fc7cf4492da3d71ae843704d183710e00f3f5b853dc6facd4d42")  -- Depot 980592
addappid(1056760,0,"1e46ab2ee8de2d7e67a7c961d64814862e8323729f0be7deeb7f9ac75820e83e")  -- Depot 1056760
addappid(1056761,0,"0407379a627760ba025f05a1d3ea50ce1bb0dfc7b8491b768b688b225e05e2c4")  -- Depot 1056761
addappid(1068290,0,"1107c219b4ea21a4ac372e06a6a62dec61bcd18479e1ac038b0a6ad52cb6a3c8")  -- Depot 1068290
addappid(1117140,0,"416b302255b34e7a36475012121166f0bdeeabec65ad6819ac2f7f36535d041f")  -- Depot 1117140
addappid(1159030,0,"7817bf09d17d1f4323c498b4dfba69731fe237a79c1880d2d5d5ffa631795084")  -- Depot 1159030
addappid(1209460,0,"f0e1ecc5f7ea5b844363c51ecf8ba76ab4f0166bbbb36f93e51a45134426a924")  -- Depot 1209460
addappid(1209461,0,"b7f8219f8fed4e94ff74b2b35e16da761eea7fd3e9ef505d77a90e4208cd050a")  -- Depot 1209461
addappid(1299530,0,"b2782485e3ba8e8c186d72a545cc77af9a7f535768efd8f7be77f8486ac1e6fa")  -- Depot 1299530
addappid(1415700,0,"4e2401eead464d941dad26b180105b715e5d5116066c00176789f32001b6ad59")  -- Depot 1415700
addappid(1456860,0,"d686ee647b9eb5e7fcd89fd7c82e7b0d201e7ca7402129d7e2de233b8bffcf8e")  -- Depot 1456860
addappid(1650650,0,"18a31f4193d242da5acc55e09f2959070cfe4a0260c63766f4b90962382a4f26")  -- Depot 1650650
addappid(1704460,0,"38c81d058e71a846f9021921aa37ddd348f9af87fd48670737deef33385cc2f9")  -- Depot 1704460
addappid(1918370,0,"33151097e4f013798a168cca80b589372225a7ac4c36f618632464a0f38629d2")  -- Depot 1918370
addappid(1967640,0,"12ad16eb6961ac01cbbb168c905eef4913188ee2ff7ee94083de1399ea9a1b08")  -- Depot 1967640
addappid(1967650,0,"8ef5c45e8e7037babf87a4985e6dbff0963fe9fbce85cea103fec9e58701335d")  -- Depot 1967650
addappid(2004210,0,"c9d6379e66ca8737ffb17de5f52a289094a0fef253746a049d15576d849d6235")  -- Depot 2004210
addappid(2193220,0,"b215faf14c32591707fbef62e913ce317843165ca9b2927ccd681a0509c2b817")  -- Depot 2193220
addappid(2371170,0,"1fcd77106389d142c555008bba4ce9bff600547c679de34c5193180067dbc949")  -- Depot 2371170
addappid(2455690,0,"aaca7608313f96a5a2ce8adc1e5ad98340690c6f2ed4c506d4efc67be45c2f31")  -- Depot 2455690
addappid(2569750,0,"27584c1ad2058a5cc6660a7728f2a7d7901d9ed31f8f6fe15d4500aac2554d32")  -- Depot 2569750
addappid(2579670,0,"ef02b23e6509e898231b08901860784e12be5be0480fec8e271171d7c79c1528")  -- Depot 2579670
addappid(2604420,0,"322d1b2e394c5b4a188fffc43809b8f8c4bb9c260e14a27c24ea217a4cb26a0c")  -- Depot 2604420
addappid(2611740,0,"72f023418f51891b17a771cd733b110c092a6a17d8dddbecc476f0fdc506fcfd")  -- Depot 2611740
addappid(2780800,0,"3e7a55f4a90a70ff249cbab7994485d13859bfb8922f22265b09b21f4b25b19c")  -- Depot 2780800
addappid(2780810,0,"c68b6cdbf16729474fb886f2a7d3a77f113ed7d4f606b0001144a95591035627")  -- Depot 2780810
addappid(2833100,0,"c4a281a6503a6911a8ed7f583a3bcfcd95738ed8f9302533c3fc53a24199ed5e")  -- Depot 2833100
addappid(2932420,0,"1bb65d2da60e4acf76f3539c02dc2a89ca727e99a4276f7c7dc3084abe451f46")  -- Depot 2932420
addappid(3034940,0,"6169b53b430db7a91db51a83ed73aa01c33f330c9f34ce1c67742a678b43b561")  -- Depot 3034940
addappid(3034950,0,"97726a24a42f14c92d1be5d998742e20c7dfaebe3c517719c0406100e472dbc1")  -- Depot 3034950
addappid(3035040,0,"265987b6be428d11dfc1ce48fabe6cd08e1382d83f8f4fea2b873f5bf04413cc")  -- Depot 3035040
addappid(3323350,0,"f052b8b9da688d69eb6b7d9162ddf68fb0caa23dcb84a22cbf5f4125399db031")  -- Depot 3323350
addappid(3323360,0,"3759b4df13b1da02928e0a58473807f4ddc07f9b1f3513dff867458136e36715")  -- Depot 3323360
addappid(3335300,0,"2a256b173394ae795423eeb99d57400944ea92248ee22379541c4f63b5e5273c")  -- Depot 3335300
addappid(3354860,0,"7ab4299e2db99a337ec4ecbda76dcd0530766e8c3790e8a0419e98f8847fa833")  -- Depot 3354860
addappid(3872920,0,"b8e6dce270a9c23586386a0b33b8815e9ca3dfaf0c0061353832ef483047ea1e")  -- Depot 3872920
addappid(3977520,0,"7aaa899d41f514cf7cb89c490327d090fd2b07fb94d058ead93b4656b71bb09b")  -- Depot 3977520
addappid(4159240,0,"904248995cb6ad9e37ff4571f34b9b6a7f9ad213b63aed13fda017cd070c8bc0")  -- Depot 4159240
addappid(4348650,0,"91bb5110513cc294bb6c83abbc92ad36f742a1c2069803635f24322c383d5617")  -- Depot 4348650
setManifestid(227301,"194425726630656285")
setManifestid(227302,"1805086626458041433")
setManifestid(227310,"551648460211125762")
setManifestid(258460,"7921356351300426751")
setManifestid(266930,"3283532009505007756")
setManifestid(266931,"4309460561061129218")
setManifestid(292320,"6527425934994182475")
setManifestid(297790,"8979825731496411430")
setManifestid(297791,"7907072597469392319")
setManifestid(297792,"2957245413978440635")
setManifestid(297793,"2905133123341935477")
setManifestid(301180,"380357946844704080")
setManifestid(304020,"7623190349550009080")
setManifestid(304140,"8467607110335293908")
setManifestid(304210,"4860658739016211282")
setManifestid(304211,"5999359468502785165")
setManifestid(304212,"3502310156915064824")
setManifestid(304213,"4371874931215817064")
setManifestid(304214,"5664607073299318301")
setManifestid(318500,"7202789966674546018")
setManifestid(318510,"7992617693705249682")
setManifestid(318511,"4628475804235513753")
setManifestid(318520,"5568977514805005034")
setManifestid(318521,"483676476628106674")
setManifestid(347190,"2376290245923035824")
setManifestid(347210,"8538423298506949843")
setManifestid(347211,"8493126685151868489")
setManifestid(347212,"280180584531605044")
setManifestid(347213,"1648858371444446407")
setManifestid(388470,"4716220128845186726")
setManifestid(388471,"763490717740367964")
setManifestid(388472,"5261877216088621057")
setManifestid(388474,"7023847166734251609")
setManifestid(388475,"5508406148406286721")
setManifestid(388476,"5959653895141705458")
setManifestid(388477,"318719124303882667")
setManifestid(388478,"614205605403850615")
setManifestid(388479,"2087101940542741745")
setManifestid(461240,"7432566952650997396")
setManifestid(461241,"4905364748903397876")
setManifestid(461242,"5400260333145696346")
setManifestid(461243,"7217290017793550202")
setManifestid(461244,"8722492570923931470")
setManifestid(461245,"627390679225060384")
setManifestid(461246,"6215803422112305490")
setManifestid(461247,"2564821458389052219")
setManifestid(461248,"9211433779081099616")
setManifestid(461249,"1714236825747095403")
setManifestid(526950,"2333631855110248746")
setManifestid(531130,"3047781383489384024")
setManifestid(531131,"620015009428909093")
setManifestid(540720,"1646764676298902558")
setManifestid(540721,"5995400305895737089")
setManifestid(558240,"702960128756830977")
setManifestid(558241,"7516040781686027632")
setManifestid(558242,"5361107034067998893")
setManifestid(558243,"7485045655295992031")
setManifestid(558244,"3775101201978954189")
setManifestid(558245,"553771190614744972")
setManifestid(876980,"6406937035159279794")
setManifestid(909640,"1919550032765055462")
setManifestid(925580,"6131130821703483172")
setManifestid(925650,"135950957944302344")
setManifestid(933610,"5991883449228130297")
setManifestid(980590,"3465626021269207986")
setManifestid(980591,"7545485906113247155")
setManifestid(980592,"3931725649050572730")
setManifestid(1056760,"2645063450082808852")
setManifestid(1056761,"4671341810091804714")
setManifestid(1068290,"1067637122708666818")
setManifestid(1117140,"7178260226727326542")
setManifestid(1159030,"1121503996381158582")
setManifestid(1209460,"8010781127620395308")
setManifestid(1209461,"3324815250320656782")
setManifestid(1299530,"2379835362999603702")
setManifestid(1415700,"4489366073136472613")
setManifestid(1456860,"61394928207200532")
setManifestid(1650650,"923355335401043994")
setManifestid(1704460,"5696023247663018301")
setManifestid(1918370,"657377999788582318")
setManifestid(1967640,"8368596210107716972")
setManifestid(1967650,"739091211669558842")
setManifestid(2004210,"8835499146116532882")
setManifestid(2193220,"3225902090318410395")
setManifestid(2371170,"5017340455997296962")
setManifestid(2455690,"7895863578875893287")
setManifestid(2569750,"7050590935326206917")
setManifestid(2579670,"1464287371127825179")
setManifestid(2604420,"8771222836869188420")
setManifestid(2611740,"5009768597697504470")
setManifestid(2780800,"6125692916729941617")
setManifestid(2780810,"6682117639283677886")
setManifestid(2833100,"5415401881972765138")
setManifestid(2932420,"8290080232077515320")
setManifestid(3034940,"2502892389353986377")
setManifestid(3034950,"3942582452463801047")
setManifestid(3035040,"230683164030405047")
setManifestid(3323350,"470794840861341618")
setManifestid(3323360,"6312086033646729789")
setManifestid(3335300,"803517503413443551")
setManifestid(3354860,"3319782812285912884")
setManifestid(3872920,"1123451156927013286")
setManifestid(3977520,"6287716840700711608")
setManifestid(4159240,"2587848077194228934")
setManifestid(4348650,"657738104977795892")
-- ═══════════════════════════════════════════════════════
-- Generated: Mon, 13 Apr 2026 13:19:39 GMT
-- Depots: 106 | Manifests: 105 | Missing: 1
-- DLCs: 106
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


