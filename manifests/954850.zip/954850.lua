-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 954850
-- Name: Kerbal Space Program 2
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Kerbal Space Program 2
-- App ID: 954850

addappid(954850)  -- Kerbal Space Program 2

addappid(954851, 1, "b3d85137cd7daf7ba9a3a458cc4e30a3995a66db4127d1b50a4d62d28b612975")  -- Depot 954851
setManifestid(954851, "3982435242459808716")

setManifestid(954852, "2894272240027278247")

setManifestid(954853, "5561556978087969695")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 09:15:48 GMT
-- Depots: 1 | Manifests: 3 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


