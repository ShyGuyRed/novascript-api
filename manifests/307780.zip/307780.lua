-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 307780
-- Name: Mortal Kombat X
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Mortal Kombat X
-- App ID: 307780

addappid(524620)  -- Kombat Pack 2 (DLC)
addappid(347880)  -- Kombat Pack (DLC)
addappid(524260)  -- Triborg (DLC)
addappid(524270)  -- Alien (DLC)
addappid(524280)  -- Bo'Rai Cho (DLC)
addappid(524290)  -- Leatherface (DLC)
addappid(524300)  -- Apocalypse Pack (DLC)
addappid(524310)  -- Cosplay Pack (DLC)
addappid(524320)  -- Krimson Ermac (DLC)

addappid(307780)  -- Mortal Kombat X

addappid(307781, 1, "1f7f19a9bf864918c90642857c72f26158edb7fad42c654c3e7b8223b22082fd")  -- Depot 307781
setManifestid(307781, "5624529206982116192")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

addappid(307782, 1, "b7d533efdd22f4207278d2b7af52a5c93640666b36c168b959de01431f2ccda5")  -- Depot 307782
setManifestid(307782, "6159674384328955878")

addappid(307783, 1, "efe55fd4dc5501e4c50424d0c60e5c358c60f555ad66ce9a22378fed90804fb9")  -- Depot 307783
setManifestid(307783, "1816684884894923223")

addappid(307784, 1, "8d29fc1cac2b2a2e6d39047616eb83fa4c83ff6cb1d74bd1453ecf9c192e61ed")  -- Depot 307784
setManifestid(307784, "3401281719433326658")

addappid(347150)  -- Jason Voorhees (DLC)
addappid(347150, 1, "567f828cb5fb9f8101da5853b9a1275d3838c209dac533643a82b4d8c238cada")  -- Depot 347150
setManifestid(347150, "4338267348866793457")

addappid(347152)  -- App 347152
addappid(347152, 1, "50dc18e35d2e4757c4e64865d5d6a6cc03e1b981530f98ab137928b51f611ee1")  -- Depot 347152
setManifestid(347152, "3968766527137329761")

addappid(347153)  -- App 347153
addappid(347153, 1, "d6827248f56319531816742fc89c2844a46a074d4e9cb751755538dd19ff04ac")  -- Depot 347153
setManifestid(347153, "8805752485552318169")

addappid(347154)  -- Unlock all Krypt Items (DLC)
addappid(347154, 1, "d42212674617019709b240ed2ae0603bd7fe3ec9910503cc566b0a1d064eabc2")  -- Depot 347154
setManifestid(347154, "2367601758245063172")

addappid(347155)  -- Blue Steel Sub-Zero (DLC)
addappid(347155, 1, "f080434be373fcc4c5e96ab2c6ed4948806fa0f599655cd78e90280119f71384")  -- Depot 347155
setManifestid(347155, "6694947482485861674")

addappid(347890)  -- Goro (DLC)
addappid(347890, 1, "42b1469fc20df168c0800d4fbc82ca39f7b7518f06e2a3d858632f83c15bfc08")  -- Depot 347890
setManifestid(347890, "9019825025781604845")

setManifestid(349160, "3224769175201645178")

setManifestid(349170, "4129468778132233337")

setManifestid(349171, "5298211571825654239")

setManifestid(349172, "6290480104705216215")

setManifestid(349173, "8822022061174500630")

setManifestid(349174, "7672366590383263962")

setManifestid(349175, "21686546119986424")

setManifestid(349176, "5053439297179071323")

setManifestid(349177, "2131332162655136475")

addappid(351550)  -- Predator (DLC)
addappid(351550, 1, "54a9ebd379096a411ae1e67d93a1bf2f50cc3b4bacccd17928a23b599441394a")  -- Depot 351550
setManifestid(351550, "8357497103448333710")

addappid(351551)  -- Tanya (DLC)
addappid(351551, 1, "0947a73c31343a6ad0be7282b34c316e14ced5474c0c07c8d40878bd463753a3")  -- Depot 351551
setManifestid(351551, "4993234369582644430")

addappid(351552)  -- Tremor (DLC)
addappid(351552, 1, "0c1192c5b43741770032760077c924160390a9a380b6a4b825c8ef3c48ed602a")  -- Depot 351552
setManifestid(351552, "443867069664371166")

addappid(351553)  -- Brazil Pack (DLC)
addappid(351553, 1, "fdd70c2164677e35183d1082e3bc37a3d5f0b8913b6b7e36157309c8bb7c41a1")  -- Depot 351553
setManifestid(351553, "8998990461481944590")

addappid(351554)  -- Klassic Pack 1 (DLC)
addappid(351554, 1, "cdffabc419554361aa64c9afdb49c77f2712c37a123af9834f244e0df7402a6d")  -- Depot 351554
setManifestid(351554, "4748821729091936932")

addappid(351555)  -- Kold War Pack (DLC)
addappid(351555, 1, "3458669120d39f55f18cdbadad33f57e49df28386576485cc2fe7b5016f144a1")  -- Depot 351555
setManifestid(351555, "6960533188296214475")

addappid(351556)  -- Samurai Pack (DLC)
addappid(351556, 1, "19dda8794a786b7f624caac1bf7808cdcf153195b68ab05c1cf6f17a0ec6f353")  -- Depot 351556
setManifestid(351556, "9098838434890469410")

setManifestid(351557, "6768511622483632716")

addappid(351558)  -- App 351558
addappid(351558, 1, "b750b2890a4757f4e6c22150deb6e904c87dc00708fdd124bac4ba1004777f1b")  -- Depot 351558
setManifestid(351558, "7593285350191767262")

setManifestid(351559, "3297137516582340465")

setManifestid(351560, "7015310348929057064")

setManifestid(351561, "1718512097511869516")

setManifestid(351562, "7388521929254760100")

setManifestid(351563, "7807628450679129450")

setManifestid(351564, "7492599004632932992")

setManifestid(354410, "133502694088544150")

setManifestid(354411, "5621916869682073374")

setManifestid(354412, "2841971059738671240")

addappid(354413)  -- App 354413
addappid(354413, 1, "e6e51d0adcf4e849a719110e9558d04d1afcf3bccbfa8ebe6235f1531c10d0ee")  -- Depot 354413
setManifestid(354413, "3458388745384864636")

setManifestid(354414, "6607478160396952820")

setManifestid(354415, "8874390319436285389")

setManifestid(354416, "4251994651374124122")

setManifestid(354417, "6607991410463469575")

setManifestid(354418, "1349276677206175215")

setManifestid(354419, "3463087192231762670")

setManifestid(354420, "1233699424752189658")

setManifestid(354421, "1238835058442055220")

addappid(354425)  -- Horror Pack (DLC)
addappid(354425, 1, "53d201ab259e97138748462c1057e239aa382d9ed22e6bd208bf583ed7c240da")  -- Depot 354425
setManifestid(354425, "7342610577311621078")

addappid(354426)  -- Klassic Pack 2 (DLC)
addappid(354426, 1, "e034af50242c1fc1dd701d027734e31c5391559e6add5c48bffef0ca87237f35")  -- Depot 354426
setManifestid(354426, "7125000413805663899")

addappid(354427)  -- Predator/Prey Pack (DLC)
addappid(354427, 1, "ff20a63957fc349d3bf2ac512655b58f979e69b49d715d4a4805a25228c9b7d3")  -- Depot 354427
setManifestid(354427, "7423120599132382125")

setManifestid(354428, "8374724956616469772")

setManifestid(354429, "9079604056224735129")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:18:39 GMT
-- Depots: 23 | Manifests: 52 | All included ✓
-- DLCs: 27
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


