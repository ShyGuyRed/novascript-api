-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 313120
-- Name: Stranded Deep
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Stranded Deep
-- App ID: 313120

addappid(313120)  -- Stranded Deep
addappid(313121,0,"849e1f5ca5a85b7d1883d504e154f01490217d7bc2833df1fc7d98a613da2053")  -- Depot 313121
addappid(313122,0,"2fecf111017e61251145acb462b843363ac5e4c14d79e159bd959ecc5bdfa6dd")  -- Depot 313122
addappid(313124,0,"6ce2cedac00fb12dc8f07843b0fe31d9a54240ed7aac46808a4cd1f27df31303")  -- Depot 313124
addappid(313125,0,"c13bc2f1874815bd732cf422e4c700677a8cfd88bd454575d5040a8dc90ac287")  -- Depot 313125
setManifestid(313121,"6975760928047011057")
setManifestid(313122,"4846953430197237657")
setManifestid(313124,"8119282937023648592")
setManifestid(313125,"2689333661829575041")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:25:20 GMT
-- Depots: 4 | Manifests: 4 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


