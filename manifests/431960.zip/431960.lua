-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 431960
-- Name: Wallpaper Engine
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Wallpaper Engine
-- App ID: 431960

addappid(431960)  -- Wallpaper Engine
addappid(431960,0,"db983bc58a8cb46d89d1d70cc962cc733956e6124c4025a0c932f82b3c37144a")  -- Depot 431960 (Shared)
addappid(1790230,0,"28aacfb757c396f07f861f189a2c2ec78653123de2177c05f94a792d1a3c8bfd")  -- Wallpaper Engine - Editor Extensions (Shared from App 1790230)
setManifestid(1790230,"4193888996927260780")
addappid(431961,0,"62ac71786b9fbeecc473fccb8a14da04ea676371addd8820638ee6cddac8c344")  -- Depot 431961
setManifestid(431961,"5641376293592905073")
addappid(431966,0,"3217352ccc45b8943d6af58c14d359a38f2897bcf4d2f7f7eb117f79f1887fc4")  -- Depot 431966
setManifestid(431966,"2667361956895452971")
-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:25:53 GMT
-- Depots: 4 | Manifests: 3 | Missing: 1
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


