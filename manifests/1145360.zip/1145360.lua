-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 1145360
-- Name: Hades
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: App 1145360
-- App ID: 1145360

addappid(1145360)  -- App 1145360

addappid(1145361, 1, "e7db1a4f43363b9d751ed9e888334353425704ea0db26c8434015e516a482f4d")  -- Depot 1145361
setManifestid(1145361, "5173085471687919135")

setManifestid(1145362, "2889773819291646530")

addappid(1145363, 1, "b88219eb2aee190d115e532ef9feea08c69bbc53bb1f959a2c48f3739f871b31")  -- Depot 1145363
setManifestid(1145363, "2572656066874346283")

addappid(1145364, 1, "c70c6707a01507e124d35ac0e1644ee6210f383a1ae759aa252478cbd1ca7e0e")  -- Depot 1145364
setManifestid(1145364, "6896671991921324741")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 15:01:54 GMT
-- Depots: 3 | Manifests: 4 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


