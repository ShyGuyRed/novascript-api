-- =====================================================
-- fetched from deathstruck db
-- =====================================================

-- AppID: 237110
-- Name: Mortal Kombat Komplete Edition
-- made by death_342

-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Mortal Kombat Komplete Edition
-- App ID: 237110

addappid(237110)  -- Mortal Kombat Komplete Edition
addappid(228982)  -- App 228982
addappid(228990)  -- App 228990
addappid(237111,0,"2c086732018a2360a855d4d934af330f401e54794f4f8880fe41f9e0b724a1e3")  -- Depot 237111 (Shared)
addappid(237112,0,"08ad2e11b65d254326f45d40a792b2687736ba990175d22c1fdaa77b103ae08d")  -- Depot 237112 (Shared)
addappid(237113,0,"44163a4633f508f0f3fb88f3312505c73b08ef29c787c5743adf862d5f598f3d")  -- Depot 237113 (Shared)
-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 11:19:12 GMT
-- Depots: 3 | Manifests: 0 | Missing: 3
-- DLCs: 2
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════


